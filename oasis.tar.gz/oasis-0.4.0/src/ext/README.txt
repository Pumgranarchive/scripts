This directory contains some generic piece of code that is not really related
to OASIS. The plan is to externalize this project if other projects need one of
them.

Don't hesitate to mail the OASIS mailing-list if you wish to externalize one
of this project.

Contact: oasis-devel AT lists.forge.ocamlcore.org
